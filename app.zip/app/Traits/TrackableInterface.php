<?php namespace App\Traits;

interface TrackableInterface {

	public function keepTrack($item);

}