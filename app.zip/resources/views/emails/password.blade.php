Click here to reset your password: <a href="{{ url('password/reset/'.$token) }}">Password Reset Link</a>
