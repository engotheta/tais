
	{!! Form::label('title_en', 'English title') !!}
	{!! Form::text('title_en',null,['class'=>'form-control']) !!}

	{!! Form::label('title_sw', 'Swahili title') !!}
	{!! Form::text('title_sw') !!}
