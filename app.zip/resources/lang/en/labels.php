<?php
namespace App;

use App\Models\Translation as Translation;

return Translation::lang('en');
